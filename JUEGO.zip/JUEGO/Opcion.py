class Opcion:
    def __init__(self, descripcion, siguienteFragmento):
        self.descripcion = descripcion
        self.siguienteFragmento = siguienteFragmento